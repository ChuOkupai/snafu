#include <snafuENG.h>

int main()
{
	snf_seteng(true);
	
	// Your code goes here...
	
	snf_seteng(false);
	return 0;
}
